## nigger.technology
### made by [zxyz](https://zxyz.best), [freeshxyz](https://freesh.xyz/)

## How to use
don't

## Compiler args
lol

## Support?
fuck off

## Localization guide
* make a new strings.lang.txt in `strings/raw`
* run `./compile.sh` in `strings`

## License
Proprietary, refrer to [LICENSE](LICENSE). ~~Many internals (CSS, build system) were based on f00f.xyz.~~ not anymore
