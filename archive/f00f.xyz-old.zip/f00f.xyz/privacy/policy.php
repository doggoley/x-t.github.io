<?php
// beta testing - new analytics engine
include('/home/www-data/analytics.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Privacy policy for f00f.xyz</title>
    <link rel="stylesheet" href="/resources/style.css">
</head>
<body>
    <noscript><center></noscript>
	<div class="privacyPolicy c">
		<h1>Privacy policy for f00f.xyz</h1>
		<p>This privacy policy applies to all projects that are hosted on f00f.xyz.</p>
		<br>
		<p>Like many other websites, we collect logs. Our logs contain</p>
		<div class="l">
			<ul>
				<li>*Your IP address</li>
				<li>*Your approximate location<a href="#c-1"><span class="sup">[1]</span></a></li>
				<li>*Your ISP</li>
				<li>Your user agent</li>
				<li>The exact time you visited one of our pages</li>
			</ul>
		</div>
        <p>This data is used to analyze our demographics.</p>
        <p>Identifying data (marked with <em>*</em>) is redacted if we receive a DNT request.</p>
		<br>
		<p>There are also other third party services that we use/may use in the future.</p>
		<p>We have no access over these third-parties and what they do with the data.</p>
		<br>
		<p>We are happy to provide your data and/or delete it as long as you can prove that the data you want to view/delete is in fact, yours.<a href="#c-2"><span class="sup">[2]</span></a></p>
		<p>For that process, consider contacting <a href="https://f00f.me">me</a>.</p>
		<br>
		<br>
		<div class="l">
			<p id="c-1"><small>[1]: The location is processed using your IP address. It <i>can</i> get your country/state, but that is about it. It's still identifying data, keep that in mind. Your location is processed by a third party (<a href="https://ipinfo.io/">ipinfo.io</a>), as explained in the section about third parties, we have NO control over them.</small></p>
			<p id="c-2"><small>[2]: GDPR says that IP addresses are identifying data. Proceeding with that process will identify your IP with your email address/any account you may contact us as. Do as you wish.</small></p>
		</div>
    </div>
    <noscript></center></noscript>
</body>
</html>
